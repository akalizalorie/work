<?php
$con=mysqli_connect("localhost","root","","idatech");
$id=$_POST['id'];
$name=$_POST['name'];
$password=$_POST['password'];
$location=$_POST['location'];

$sql="UPDATE user SET id='$id',name='$name',password='$password',location='$location' WHERE id='$id'";
$a=mysqli_query($con,$sql);
header("location:updateform.php");

?>