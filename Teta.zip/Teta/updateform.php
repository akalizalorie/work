<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form method="POST" action="update.php">
      
        <label>id</label><br></br>
        <input type="text" name="id"><br>        
        <label>name</label><br></br>
        <input type="text" name="name"><br>        
        <label>password</label><br></br>
        <input type="password" name="password"><br> 
        <label>location</label><br></br>
        <input type="text" name="location"><br> 
        
    <input type="submit" value="Update"><br></br>

    </form>
</body>
</html>