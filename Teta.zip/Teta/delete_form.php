<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="delete.php">
        <label>id</label>
        <input type="text" name="id" placeholder="Enter id">
        <input type="submit" value="delete">
</form>
</body>
</html>