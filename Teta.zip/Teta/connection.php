<?php
$con=mysql_connect("localhost","root","","teta");
if($con==true){
    echo"connected";
}
else{
    echo"not connected";
    
}


?>