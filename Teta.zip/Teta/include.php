<?php
$con=mysql_connect("localhost","root","","teta");
$id=$_POST['id'];
$student_name=$_POST['student_name'];
$age=$_POST['age'];
$sex=$_POST['sex'];
$sql="INSERT INTO student VALUES('$id','$student_name','$age','$sex')";
$id=mysql_query($con,$sql);
header("location:studentss.php");
?>